	<!-- Footer -->
	<div id="footer">
		<div class="copyright">Copyright © 2010 TITANIUM FOLIO</div>
		<div class="social">
			<ul>
				<li><a href="http://facebook.com"><img src="images/facebook.png" alt="" /></a></li>
				<li><a href="http://twitter.com/mariuspop"><img src="images/twitter.png" alt="" /></a></li>
				<li><a href="http://flickr.com"><img src="images/flickr.png" alt="" /></a></li>
				<li><a href="http://linkedin.com"><img src="images/linkedin.png" alt="" /></a></li>
			</ul>
		</div>
		<div class="clearfloat"></div>
	</div>

</div>

<script type="text/javascript">
	$('#style-switcher a').styleSwitcher();
</script>

</body>
</html>