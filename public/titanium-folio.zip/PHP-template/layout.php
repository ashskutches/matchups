<?php include("header.php"); ?>

<div id="wrapper">
	<!-- Page header -->
	<div class="page_header">
		<h1 class="bebas-font">layout</h1>
		<h2 class="bebas-font">providing client services in web, print and multimedia design</h2>
		<div class="clearfloat"></div>
	</div>
	
	<!-- Breadcrumb -->
	<div class="breadcrumb">
		<ul>
			<li><a href="index.php">Home</a>&nbsp;&nbsp;//&nbsp;&nbsp;</li>
			<li>Layout</li>
		</ul>
		<div class="clearfloat"></div>
	</div>
	
	<!-- Page content -->
	<div class="page_content">	  
		
			<div class='col4' >
				<h2 class="bebas-font">Col 4</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus.</p>
				<p> 
				<pre>&lt;div class="col4"&gt;<br /> content here<br />&lt;div&gt;</pre>
				</p> 
			</div>
			
			<div class='col4' >
				<h2 class="bebas-font">Col 4</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus.</p>
				<p> 
				<pre>&lt;div class="col4"&gt;<br /> content here<br />&lt;div&gt;</pre>
				</p> 
			</div>
			
			<div class='col4' >
				<h2 class="bebas-font">Col 4</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus.</p>
				<p> 
				<pre>&lt;div class="col4"&gt;<br /> content here<br />&lt;div&gt;</pre>
				</p> 
			</div>
			
			<div class='col4' >
				<h2 class="bebas-font">Col 4</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus.</p>
				<p> 
				<pre>&lt;div class="col4"&gt;<br /> content here<br />&lt;div&gt;</pre>
				</p> 
			</div>						
			
			<hr />
			<div class='col3' >
				<h2 class="bebas-font">Col 3</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. 
				Phasellus non ultricies orci. Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula.</p>
				<p><pre>&lt;div class="col3"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<div class='col3' >
				<h2 class="bebas-font">Col 3</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. 
				Phasellus non ultricies orci. Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula.</p>
				<p><pre>&lt;div class="col3"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<div class='col3' >
				<h2 class="bebas-font">Col 3</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. 
				Phasellus non ultricies orci. Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula.</p>
				<p><pre>&lt;div class="col3"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<hr />
			<div class='col2'>
				<h2 class="bebas-font">Col 2</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. Phasellus non ultricies orci. 
				Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula.</p>
				<p><pre>&lt;div class="col2"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<div class='col2'>
				<h2 class="bebas-font">Col 2</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. Phasellus non ultricies orci. 
				Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula.</p>
				<p><pre>&lt;div class="col2"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<hr />
			<div class='col2' >
				<h2 class="bebas-font">Col 2</h2>			
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. Phasellus non ultricies orci. 
				Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus.</p>
				<p><pre>&lt;div class="col2"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div> 
			
			<div class='col4' >
				<h2 class="bebas-font">Col 4</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus.</p>
				<p><pre>&lt;div class="col4"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div> 
			
			<div class='col4' >
				<h2 class="bebas-font">Col 4</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus.</p>
				<p><pre>&lt;div class="col4"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<hr />
			<div class='col32' >
				<h2 class="bebas-font">Col 2/3</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. Phasellus non ultricies orci. 
				Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula. 
				Duis ac purus non tellus pharetra imperdiet.</p>
				<p><pre>&lt;div class="col32"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<div class='col3' >
				<h2 class="bebas-font">Col 3</h2>
				<p>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. Phasellus non ultricies orci. 
				Sed a viverra.</p>
				<p><pre>&lt;div class="col3"&gt;<br /> content here<br />&lt;div&gt;</pre></p>
			</div>
			
			<hr />
			<div class="col1">
				<h2 class="bebas-font">Quotes</h2>
				<p><blockquote>Vivamus vel enim est. Morbi mollis velit quis tortor rhoncus ac consectetur enim dapibus. 
				Phasellus non ultricies orci. Sed a viverra lectus. Proin id urna enim. Ut fermentum lectus et ipsum vehicula et porttitor diam vehicula. 
				Duis ac purus non tellus pharetra imperdiet. Sed suscipit fringilla viverra. Sed in elit sed magna pharetra dignissim.</blockquote></p>
				<p><pre>&lt;blockquote&gt; content here &lt;/blockquote&gt;</pre></p>
			</div>
			<hr />
			
			<div class="col1">
				<h2 class="bebas-font">Buttons</h2>			
				<p><a class="titanium_button" href="your_link"><span>button</span></a></p>
				<p><pre>&lt;a href="your_link" class="titanium_button"&gt; &lt;span&gt;button&lt;/span&gt; &lt;/a&gt;</pre></p><br />
				
				<p><a class="more_btn" href="">View more</a></p>
				<p><pre>&lt;a href="your_link" class="more_btn"&gt; View more &lt;/a&gt;</pre></p><br />
			</div>
						
			<hr />
			<div class="col1">
				<h2 class="bebas-font">Info boxes</h2>
				<div class="titanium_info" >
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam  nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat 
					volutpat. Ut wisi enim ad minim veniam, quis nostrud exercitation  ulliam corper suscipit lobortis nisl ut aliquip ex ea commodo 
					consequat. 
				</div>
				<p><pre>&lt;div class="titanium_info"&gt; content here &lt;/div&gt;</pre></p><br />
				
				<div class="titanium_warning" >
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam  nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam 
					erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exercitation  ulliam corper suscipit lobortis nisl ut aliquip ex ea commodo 
					consequat. 
				</div>
				<p><pre>&lt;div class="titanium_warning"&gt; content here &lt;/div&gt;</pre></p><br />
			
				<div class="titanium_successful">
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam  nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam 
					erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exercitation  ulliam corper suscipit lobortis nisl ut aliquip ex ea commodo 
					consequat. 
				</div>
				<p><pre>&lt;div class="titanium_successful"&gt; content here &lt;/div&gt;</pre></p><br />
				
				<div class="titanium_error">
					Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam  nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam 
					erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exercitation  ulliam corper suscipit lobortis nisl ut aliquip ex ea commodo 
					consequat. 
				</div>
				<p><pre>&lt;div class="titanium_error"&gt; content here &lt;/div&gt;</pre></p><br />
			</div>
    		
	</div>
	
<?php include("footer.php"); ?>